let comprimentoTela = 800;
let larguraTela = 600;
let xBolinha = comprimentoTela / 2;
let yBolinha = larguraTela / 2;
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;
let diametroBolinha = 20;
let raioBolinha = diametroBolinha;
let larguraRaquete = 10;
let comprimentoRaquete = 80;
let xMinhaRaquete = 10;
let yMinhaRaquete = 300;
let xRaqueteOponente = comprimentoTela - larguraRaquete -10
let yRaqueteOponente = 300;
let colidiu = false;
let velocidadeYOponente;
let meusPontos = 0;
let pontosOponente = 0

//tela
function setup() {
  createCanvas(comprimentoTela, larguraTela);
}
//draw
function draw() {
  background(0);
  criaBolinha();
  moveBolinha();
  colideBolinha();
  criaRaquete(xMinhaRaquete, yMinhaRaquete);
  criaRaquete(xRaqueteOponente, yRaqueteOponente);
  moveMinhaRaquete();
  //colideRaquete
  colisaoRaquete(xMinhaRaquete,yMinhaRaquete);
  colisaoRaquete(xRaqueteOponente,yRaqueteOponente);
  mostraPlacar()
  pontosJogo
}
//bolinha
function criaBolinha() {
  circle(xBolinha, yBolinha, diametroBolinha);
}
function moveBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}
function colideBolinha() {
  if (xBolinha + raioBolinha > comprimentoTela || xBolinha - raioBolinha < 0) {
    velocidadeXBolinha = velocidadeXBolinha * -1;
  }
  if (yBolinha + raioBolinha > larguraTela || yBolinha - raioBolinha < 0) {
    velocidadeYBolinha = velocidadeYBolinha * -1;
  }
}

//raquete
function criaRaquete(posicaoX, posicaoY) {
  rect(posicaoX, posicaoY, larguraRaquete, comprimentoRaquete);
}

function moveMinhaRaquete() {
  if (keyIsDown(UP_ARROW)) {
    yMinhaRaquete -= 10;
  }

  if (keyIsDown(DOWN_ARROW)) {
    yMinhaRaquete += 10;
  }
  yRaqueteOponente = yBolinha - comprimentoRaquete/2
}

//colisão
function colideRaquete() {
  if (
    xBolinha - raioBolinha < xMinhaRaquete + larguraRaquete &&
    yBolinha - raioBolinha < xMinhaRaquete + comprimentoRaquete &&
    yBolinha + raioBolinha > yMinhaRaquete
  ) {
    velocidadeXBolinha *= -1;
  }
}
 function colisaoRaquete(posicaoX, posicaoY){
   colidiu = collideRectCircle(
   posicaoX,
   posicaoY,
   larguraRaquete,
   comprimentoRaquete,
   xBolinha,
   yBolinha,
   diametroBolinha)
   
   if (colidiu){
     velocidadeXBolinha *= -1;
   }
   function mostrarPlacar(){
     fill (255);
     textSize (30);
     text (meusPontos, 200, 50);
     text (pontosOponente,600, 50)
    
   }
   
   function pontosJogo(){
     if (xBolinha> 790)
      { 
      meusPontos+= 1}
       if (xBolinha
     
     
     
   }
     
   
   
 } 
 function moveRaqueteOponente(){
   velocidadeYOponente = yBolinha - yRaqueteOponente - comprimentoRaquete / 2-30
   yRaqueteOponente = velocidadeYOponente
 }

  